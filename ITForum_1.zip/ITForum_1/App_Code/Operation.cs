﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Operation 的摘要说明
/// </summary>
public class Operation
{
    DataBase data = new DataBase();
    public Operation()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }

    

    #region 登录
    public DataSet login(string user, string pwd)
    {
        return data.RunProcReturn("Select * from tb_user where id='" + user + "' and pwd='" + pwd + "'", "tb_user");
    }

    

    #endregion

    #region 个人信息
    public  DataSet personalInfo(String user)
    {
        return data.RunProcReturn("select * from tb_user " +
            "where id='"+user+"'", "tb_user");
    }

    #endregion

    #region 问题列表 
    public DataSet questionTitle()
    {
        return data.RunProcReturn("select * from tb_question", "tb_question");
    }
    #endregion

    #region 问题回答
    public DataSet questionAnswer(String question_id)
    {
        return data.RunProcReturn("select * from tb_answer " +
            "where question_id='" + question_id + "'", "tb_answer");
    }
    #endregion

    #region 回答标题
    public DataSet answerTitle(String question_id)
    {
        return data.RunProcReturn("select * from tb_question " +
            "where id='" + question_id + "'", "tb_question");
    }
    #endregion

    #region 发布评论
    public int answerRelease(String question_id, String user_id, String ans, String ans_time)
    {
        return data.RunProc("insert into tb_answer values (" 
            + "'" + int.Parse(question_id) + "','"
             + int.Parse(user_id) + "','"
              + ans + "','"
               + ans_time + "')");
    }
    #endregion
}