﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class QuestionRequest : System.Web.UI.Page
{
    Operation operation = new Operation();
    protected void Page_Load(object sender, EventArgs e)
    {
        question_title.DataSource = operation.answerTitle(Request.QueryString["id"]);
        answer.DataSource = operation.questionAnswer(Request.QueryString["id"]);
        question_title.DataBind();
        answer.DataBind();
    }

    protected void release_Click(object sender, EventArgs e)
    {
        operation.answerRelease(Request.QueryString["id"], Session["UserName"].ToString(), ans.Text.Trim(), DateTime.Now.ToLocalTime().ToString());
        Response.AddHeader("Refresh", "0");
    }
}