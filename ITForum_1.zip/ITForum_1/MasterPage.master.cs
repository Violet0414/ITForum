﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    Operation operation = new Operation();
    protected void Page_Load(object sender, EventArgs e)
    {
        dlInfo.DataSource = operation.personalInfo(Session["UserName"].ToString());
        dlInfo.DataBind();
    }
}
